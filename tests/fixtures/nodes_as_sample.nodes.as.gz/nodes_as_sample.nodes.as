# CAIDA Ark IPv6 topology nodes
# measurement date: 20240315
N 2001:db8::1 64496
N 2001:db8::2 64496
N 2001:db8:1::1 64497
N ::ffff:1.2.3.4 64496
L some-link-record ignored
N 2001:db9::1 *
N 2001:db8::3 not_a_number
